package com.example.deber3_inkiit_rview

import android.graphics.drawable.Drawable

class recommendation(
    var coverR: Int,
    var tituloR: String?,
    var descripcionR: String?,
) {
}