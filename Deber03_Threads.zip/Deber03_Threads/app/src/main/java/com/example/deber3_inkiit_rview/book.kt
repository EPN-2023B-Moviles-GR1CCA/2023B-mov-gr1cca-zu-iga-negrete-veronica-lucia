package com.example.deber3_inkiit_rview
import android.graphics.drawable.Drawable


class book (
    var titulo: String?,
    var autor: String?,
    var descripcion: String?,
    var estado: String?,
    var calificacion: Double?,
    var coverBook: Int
) {

}